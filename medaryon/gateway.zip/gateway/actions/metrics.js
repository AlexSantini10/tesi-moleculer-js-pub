const { register } = require("../utils/prometheus");

module.exports = {
	rest: "GET /metrics",

	// endpoint che espone metriche Prometheus
	async handler() {
		try {
			const metrics = await register.metrics();
			return {
				type: "text/plain; version=0.0.4; charset=utf-8",
				body: String(metrics)
			};
		} catch (err) {
			return {
				type: "text/plain; version=0.0.4; charset=utf-8",
				body: "metrics unavailable",
				code: 500
			};
		}
	}
};
