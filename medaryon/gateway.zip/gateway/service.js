"use strict";

const ApiGateway = require("moleculer-web");
const jwt = require("jsonwebtoken");
const os = require("os");

const nodesAction = require("./actions/nodes");
const metricsAction = require("./actions/metrics");
const statsAction = require("./actions/stats");

const { httpRequests, httpRequestDuration } = require("./utils/prometheus");
const Errors = require("../errors");

module.exports = {
	name: "gateway",
	mixins: [ApiGateway],
	autoAliases: true,

	/**
	 * Verificare presenza di JWT_SECRET all'avvio (fail fast)
	 */
	created() {
		if (!process.env.JWT_SECRET || String(process.env.JWT_SECRET).trim().length === 0) {
			throw new Error("JWT_SECRET mancante: impossibile avviare il gateway senza chiave.");
		}
	},

	settings: {
		routes: [{
			path: "/api",
			mappingPolicy: "all",
			cors: true,
			authentication: true,
			authorization: false,

			aliases: {
				"GET /metrics": "gateway.metrics",
				"GET /nodes": "gateway.nodes",
				"GET /stats": "gateway.stats"
			},

			// Middleware per metriche HTTP (Prometheus)
			use: [
				async function (req, res, next) {
					const end = httpRequestDuration.startTimer();
					res.on("finish", function () {
						const labels = {
							method: req.method,
							route: (req.$endpoint && req.$endpoint.route && req.$endpoint.route.path) ? req.$endpoint.route.path : req.url,
							status: res.statusCode
						};
						httpRequests.inc(labels);
						end(labels);
					});
					next();
				}
			]
		}]
	},

	actions: {
		nodes: nodesAction,
		metrics: metricsAction,
		stats: statsAction
	},

	methods: {
		/**
		 * Autenticare le richieste non pubbliche tramite JWT Bearer
		 * Ritornare `null` per azioni pubbliche
		 */
		async authenticate(ctx, route, req, res) {
			const DEBUG = process.env.DEBUG === "true";

			if (DEBUG) {
				this.logger.info("authenticate() invoked");
				this.logger.info("Route path:", route && route.path);
				this.logger.info("Request method:", req && req.method);
				this.logger.info("Request URL:", req && req.url);
				this.logger.info("Request headers:", req && req.headers);
			}

			// Determinare l'azione risolta
			const action = req.$endpoint && req.$endpoint.action;
			const actionName = action && action.name;

			if (DEBUG) {
				this.logger.info("Resolved action name:", actionName);
			}

			// Azioni pubbliche che non richiedono token
			const publicActions = new Set([
				"gateway.metrics",
				"gateway.nodes",
				"gateway.stats",
				"users.register",
				"users.login",
				"users.forgotPassword",
				"users.resetPassword"
			]);

			if (publicActions.has(actionName)) {
				if (DEBUG) this.logger.info("Public action. Skipping auth.");
				return null;
			}

			// Per le altre azioni, richiedere Bearer token
			const authHeader = req.headers && req.headers["authorization"];
			if (DEBUG) this.logger.info("Authorization header present:", !!authHeader);

			if (!authHeader || authHeader.indexOf("Bearer ") !== 0) {
				this.logger.warn("Missing or malformed Authorization header");
				throw Errors.MissingTokenError();
			}

			const token = authHeader.slice(7);

			if (DEBUG) {
				const masked = (token.length > 10) ? token.slice(0, 5) + "..." + token.slice(-5) : "***";
				this.logger.info("JWT received (masked):", masked, " length:", token.length);
			}


			try {
				const decoded = jwt.verify(token, process.env.JWT_SECRET);
				const user = {
					id: decoded && decoded.id,
					role: decoded && decoded.role,
					email: decoded && decoded.email
				};
				if (DEBUG) this.logger.info("JWT decoded:", user);
				return user; // assegnato a ctx.meta.user da moleculer-web
			} catch (err) {
				this.logger.warn("JWT verification failed:", err && err.message);
				if (DEBUG && err && err.stack) this.logger.debug("JWT verification stack:", err.stack);
				throw Errors.InvalidTokenError();
			}
		},

		/**
		 * Restituire statistiche di sistema basilari
		 */
		getSystemStats() {
			return {
				uptime: process.uptime(),
				hostname: os.hostname(),
				platform: os.platform(),
				arch: os.arch(),
				cpus: os.cpus().length,
				memory: {
					total: os.totalmem(),
					free: os.freemem()
				},
				load: os.loadavg()
			};
		}
	}
};
