const client = require("prom-client");

// Registry globale Prometheus
const register = new client.Registry();

// Raccogliere metriche di sistema (CPU, memoria, ecc.)
client.collectDefaultMetrics({ register });

// Counter per numero di richieste HTTP
const httpRequests = new client.Counter({
	name: "http_requests_total",
	help: "Numero di richieste HTTP totali",
	labelNames: ["method", "route", "status"]
});

// Histogram per la durata delle richieste HTTP
const httpRequestDuration = new client.Histogram({
	name: "http_request_duration_seconds",
	help: "Durata delle richieste HTTP in secondi",
	labelNames: ["method", "route", "status"],
	buckets: [0.1, 0.3, 0.5, 1, 1.5, 2, 5]
});

// Registrare metriche personalizzate
register.registerMetric(httpRequests);
register.registerMetric(httpRequestDuration);

module.exports = {
	register,
	httpRequests,
	httpRequestDuration
};
