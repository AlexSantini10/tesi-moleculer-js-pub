"use strict";

/**
 * Pagamento fallito per un appuntamento.
 * Se era "requested", annulla l'appuntamento.
 *
 * payload.data = { appointmentId }
 */
module.exports = async function(payload) {
	try {
		const apptId = payload && payload.data ? Number(payload.data.appointmentId) : null;
		if (!apptId) return;

		const [affected] = await this.Appointment.update(
			{ status: "cancelled" },
			{
				where: {
					id: apptId,
					status: "requested"
				}
			}
		);

		this.logger.info("payments.payment.failed -> cancelled appointment", { apptId, affected });
	} catch (err) {
		this.logger.error("payments.payment.failed handler error", { err: err && err.message });
	}
};
