"use strict";

const { Op } = require("sequelize");

/**
 * Un utente è stato eliminato/disattivato.
 * Annulla gli appuntamenti futuri in stato "requested" o "confirmed"
 * dove l'utente è paziente o dottore.
 *
 * payload.data = { userId, reason? }
 */
module.exports = async function(payload) {
	try {
		const userId = payload && payload.data ? Number(payload.data.userId) : null;
		if (!userId) return;

		const where = {
			status: { [Op.in]: ["requested", "confirmed"] },
			[Op.or]: [
				{ patient_id: userId },
				{ doctor_id: userId }
			]
		};

		const [affected] = await this.Appointment.update(
			{ status: "cancelled" },
			{ where }
		);

		this.logger.info("users.user.deleted -> cancelled appointments", { userId, affected });
	} catch (err) {
		this.logger.error("users.user.deleted handler error", { err: err && err.message });
	}
};
