"use strict";

const { Op } = require("sequelize");

/**
 * Uno slot è stato modificato (es. orario spostato).
 * Se legato ad un appointment, aggiorna l'orario.
 *
 * payload.data = {
 * 	appointmentId?, to?: { start, end }, doctorId?
 * }
 * Preferenza: usa appointmentId.
 */
module.exports = async function(payload) {
	try {
		const data = payload && payload.data ? payload.data : {};
		if (data.appointmentId && data.to && data.to.start) {
			const apptId = Number(data.appointmentId);
			const next = new Date(data.to.start);

			const [affected] = await this.Appointment.update(
				{ scheduled_at: next },
				{
					where: {
						id: apptId,
						status: { [Op.in]: ["requested", "confirmed"] }
					}
				}
			);

			this.logger.info("availability.slot.updated -> rescheduled by appointmentId", { apptId, affected });
			return;
		}

		// fallback minimale: se fornito doctorId+to.start, prova a matchare
		if (data.doctorId && data.to && data.to.start) {
			const [affected] = await this.Appointment.update(
				{ scheduled_at: new Date(data.to.start) },
				{
					where: {
						doctor_id: Number(data.doctorId),
						status: { [Op.in]: ["requested", "confirmed"] }
					}
				}
			);
			this.logger.info("availability.slot.updated -> rescheduled by doctorId", { doctorId: data.doctorId, affected });
		}
	} catch (err) {
		this.logger.error("availability.slot.updated handler error", { err: err && err.message });
	}
};
