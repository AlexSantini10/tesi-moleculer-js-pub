"use strict";

const { Op } = require("sequelize");

/**
 * Uno slot di disponibilità è stato rimosso.
 * Se c'è un appointment collegato, annullalo.
 *
 * payload.data = { appointmentId? , doctorId?, start? }
 * Preferenza: usa appointmentId; in fallback prova a matchare doctorId + start.
 */
module.exports = async function(payload) {
	try {
		const data = payload && payload.data ? payload.data : {};
		let where = null;

		if (data.appointmentId) {
			where = { id: Number(data.appointmentId), status: { [Op.in]: ["requested", "confirmed"] } };
		} else if (data.doctorId && data.start) {
			where = {
				doctor_id: Number(data.doctorId),
				scheduled_at: new Date(data.start),
				status: { [Op.in]: ["requested", "confirmed"] }
			};
		}

		if (!where) return;

		const [affected] = await this.Appointment.update(
			{ status: "cancelled" },
			{ where }
		);

		this.logger.info("availability.slot.deleted -> cancelled appointments", { affected });
	} catch (err) {
		this.logger.error("availability.slot.deleted handler error", { err: err && err.message });
	}
};
