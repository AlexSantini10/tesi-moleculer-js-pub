"use strict";

const { Op } = require("sequelize");

/**
 * Pagamento completato per un appuntamento.
 * Conferma l'appuntamento se era "requested".
 *
 * payload.data = { appointmentId }
 */
module.exports = async function(payload) {
	try {
		const apptId = payload && payload.data ? Number(payload.data.appointmentId) : null;
		if (!apptId) return;

		const [affected] = await this.Appointment.update(
			{ status: "confirmed" },
			{
				where: {
					id: apptId,
					status: "requested"
				}
			}
		);

		this.logger.info("payments.payment.completed -> confirmed appointment", { apptId, affected });
	} catch (err) {
		this.logger.error("payments.payment.completed handler error", { err: err && err.message });
	}
};
