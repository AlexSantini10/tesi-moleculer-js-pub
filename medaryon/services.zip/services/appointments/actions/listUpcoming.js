const { Op } = require("sequelize");
const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		user_id: { type: "number", optional: true },
		role: { type: "enum", optional: true, values: ["patient", "doctor"] }
	},

	async handler(ctx) {
		// accetta sia querystring (GET) che body (POST)
		const user_id = Number((ctx.params && ctx.params.user_id) || (ctx.meta && ctx.meta.user && ctx.meta.user.id));
		const role = (ctx.params && ctx.params.role) || (ctx.meta && ctx.meta.user && ctx.meta.user.role);

		if (!user_id || !role) {
			throw new MoleculerClientError("user_id and role are required", 422, "INVALID_PARAMS");
		}

		const u = this.getRequester(ctx);
		if (!u) throw new MoleculerClientError("Unauthorized", 401, "UNAUTHORIZED");
		if (!this.isAdmin(ctx)) {
			if (role === "patient") {
				if (!(this.isPatient(ctx) && Number(u.id) === Number(user_id))) throw new MoleculerClientError("Forbidden", 403, "FORBIDDEN");
			} else if (role === "doctor") {
				if (!(this.isDoctor(ctx) && Number(u.id) === Number(user_id))) throw new MoleculerClientError("Forbidden", 403, "FORBIDDEN");
			} else {
				throw new MoleculerClientError("Invalid role", 422, "INVALID_ROLE");
			}
		}

		const where = {
			scheduled_at: {
				[Op.gte]: new Date()
			},
			status: { [Op.in]: ["requested", "confirmed"] }
		};

		if (role === "patient") {
			where.patient_id = user_id;
		} else {
			where.doctor_id = user_id;
		}

		const items = await this.Appointment.findAll({
			where,
			order: [["scheduled_at", "ASC"]]
		});

		return items.map(a => this.sanitizePayload(a));
	}
};
