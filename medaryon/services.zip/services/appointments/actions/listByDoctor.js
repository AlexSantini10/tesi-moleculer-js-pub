const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		doctor_id: "number"
	},

	async handler(ctx) {
		const { doctor_id } = ctx.params;

		const u = this.getRequester(ctx);
		if (!u) throw new MoleculerClientError("Unauthorized", 401, "UNAUTHORIZED");
		if (!this.isAdmin(ctx)) {
			// solo il dottore stesso può vedere i propri
			if (!(this.isDoctor(ctx) && Number(u.id) === Number(doctor_id))) {
				throw new MoleculerClientError("Forbidden", 403, "FORBIDDEN");
			}
		}

		const items = await this.Appointment.findAll({
			where: { doctor_id },
			order: [["scheduled_at", "DESC"]]
		});

		return items.map(a => this.sanitizePayload(a));
	}
};
