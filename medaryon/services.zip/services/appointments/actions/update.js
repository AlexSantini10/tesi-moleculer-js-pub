const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		id: "number",
		scheduled_at: { type: "string", optional: true },
		notes: { type: "string", optional: true }
	},

	async handler(ctx) {
		const { id, scheduled_at, notes } = ctx.params;

		const appt = await this.Appointment.findByPk(id);
		if (!appt) {
			throw new MoleculerClientError("Appointment not found", 404, "NOT_FOUND");
		}

		this.ensureCanModify(ctx, appt);

		if (scheduled_at) {
			const when = this.parseISODate(scheduled_at, "scheduled_at");
			this.ensureFuture(when, "scheduled_at");
			await this.assertNoConflict({ doctor_id: appt.doctor_id, scheduled_at: when, excludeId: appt.id });
			appt.scheduled_at = when;
		}

		if (typeof notes === "string") {
			appt.notes = notes;
		}

		try {
			await appt.save();
			return this.sanitizePayload(appt);
		} catch (err) {
			this.logger.error("Update appointment failed", err);
			throw this.mapSequelizeError(err, "Failed to update appointment");
		}
	}
};
