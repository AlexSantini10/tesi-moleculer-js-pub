const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		id: "number"
	},

	async handler(ctx) {
		const { id } = ctx.params;

		if (!this.isAdmin(ctx)) {
			throw new MoleculerClientError("Forbidden", 403, "FORBIDDEN");
		}

		const appt = await this.Appointment.findByPk(id);
		if (!appt) {
			throw new MoleculerClientError("Appointment not found", 404, "NOT_FOUND");
		}

		try {
			await appt.destroy();
			return { id: appt.id, removed: true };
		} catch (err) {
			this.logger.error("Hard remove failed", err);
			throw this.mapSequelizeError(err, "Failed to remove appointment");
		}
	}
};
