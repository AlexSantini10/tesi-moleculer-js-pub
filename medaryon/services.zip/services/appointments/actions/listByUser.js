const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		patient_id: "number"
	},

	async handler(ctx) {
		const { patient_id } = ctx.params;

		const u = this.getRequester(ctx);
		if (!u) throw new MoleculerClientError("Unauthorized", 401, "UNAUTHORIZED");
		if (!this.isAdmin(ctx)) {
			// solo il paziente stesso può vedere i propri
			if (!(this.isPatient(ctx) && Number(u.id) === Number(patient_id))) {
				throw new MoleculerClientError("Forbidden", 403, "FORBIDDEN");
			}
		}

		const items = await this.Appointment.findAll({
			where: { patient_id },
			order: [["scheduled_at", "DESC"]]
		});

		return items.map(a => this.sanitizePayload(a));
	}
};
