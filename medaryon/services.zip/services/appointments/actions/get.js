const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		id: "number"
	},

	async handler(ctx) {
		const { id } = ctx.params;
		const appt = await this.Appointment.findByPk(id);
		if (!appt) {
			throw new MoleculerClientError("Appointment not found", 404, "NOT_FOUND");
		}
		this.ensureCanView(ctx, appt);
		return this.sanitizePayload(appt);
	}
};
