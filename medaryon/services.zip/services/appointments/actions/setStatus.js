const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		id: "number",
		status: {
			type: "enum",
			values: ["requested", "confirmed", "cancelled", "completed"]
		}
	},

	async handler(ctx) {
		const { id, status } = ctx.params;

		const appt = await this.Appointment.findByPk(id);
		if (!appt) {
			throw new MoleculerClientError("Appointment not found", 404, "NOT_FOUND");
		}

		// validazione e permessi di transizione
		this.ensureStatusTransition(ctx, appt, status);

		// nessuna modifica se già nello stato target
		if (appt.status === status) {
			return this.sanitizePayload(appt);
		}

		appt.status = status;

		try {
			await appt.save();
			return this.sanitizePayload(appt);
		} catch (err) {
			this.logger.error("Set status failed", err);
			throw this.mapSequelizeError(err, "Failed to set status");
		}
	}
};
