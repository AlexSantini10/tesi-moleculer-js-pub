const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		id: "number",
		new_date: "string" // ISO 8601
	},

	async handler(ctx) {
		const { id, new_date } = ctx.params;

		const appt = await this.Appointment.findByPk(id);
		if (!appt) {
			throw new MoleculerClientError("Appointment not found", 404, "NOT_FOUND");
		}

		this.ensureCanModify(ctx, appt);

		const when = this.parseISODate(new_date, "new_date");
		this.ensureFuture(when, "new_date");

		await this.assertNoConflict({ doctor_id: appt.doctor_id, scheduled_at: when, excludeId: appt.id });

		appt.scheduled_at = when;

		try {
			await appt.save();
			return this.sanitizePayload(appt);
		} catch (err) {
			this.logger.error("Reschedule failed", err);
			throw this.mapSequelizeError(err, "Failed to reschedule appointment");
		}
	}
};
