const { Errors } = require("moleculer");
const { MoleculerClientError } = Errors;

module.exports = {
	params: {
		patient_id: { type: "number", convert: true },
		doctor_id: { type: "number", convert: true },
		scheduled_at: "string",
		notes: { type: "string", optional: true }
	},

	async handler(ctx) {
		const patient_id = Number(ctx.params.patient_id);
		const doctor_id = Number(ctx.params.doctor_id);
		const { scheduled_at, notes } = ctx.params;

		this.ensureCanCreate(ctx, { patient_id, doctor_id });

		const when = this.parseISODate(scheduled_at, "scheduled_at");
		this.ensureFuture(when, "scheduled_at");

		await this.assertNoConflict({ doctor_id, scheduled_at: when });

		try {
			const appt = await this.Appointment.create({
				patient_id,
				doctor_id,
				scheduled_at: when,
				status: "requested",
				notes: notes || null
			});
			return this.sanitizePayload(appt);
		} catch (err) {
			this.logger.error("Create appointment failed", err);
			throw this.mapSequelizeError(err, "Failed to create appointment");
		}
	}
};
