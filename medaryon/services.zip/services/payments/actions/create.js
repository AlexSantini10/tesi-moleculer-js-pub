"use strict";

module.exports = {
	rest: {
		method: "POST",
		path: "/"
	},
	params: {
		user_id: { type: "number", integer: true, positive: true },
		appointment_id: { type: "number", integer: true, positive: true },
		amount: { type: "string" },
		currency: { type: "string", optional: true },
		method: { type: "string" },
		provider: { type: "string", optional: true },
		provider_payment_id: { type: "string", optional: true },
		metadata: { type: "any", optional: true }
	},
	async handler(ctx) {
		const payload = {
			user_id: ctx.params.user_id,
			appointment_id: ctx.params.appointment_id,
			amount: ctx.params.amount,
			currency: ctx.params.currency || "EUR",
			method: ctx.params.method,
			status: "pending",
			provider: ctx.params.provider || null,
			provider_payment_id: ctx.params.provider_payment_id || null,
			metadata: this.safeParseJSON(ctx.params.metadata)
		};

		const created = await this.withTx(async (t) => {
			return this.Payment.create(payload, { transaction: t });
		});

		return created.toJSON();
	}
};
