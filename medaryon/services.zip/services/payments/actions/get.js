"use strict";

module.exports = {
	rest: {
		method: "GET",
		path: "/:id"
	},
	params: {
		id: { type: "number", integer: true, positive: true }
	},
	async handler(ctx) {
		const row = await this.Payment.findByPk(ctx.params.id);
		if (!row) {
			throw new Error("Payment not found");
		}
		return row.toJSON();
	}
};
