"use strict";

module.exports = {
	rest: {
		method: "DELETE",
		path: "/:id"
	},
	params: {
		id: { type: "number", integer: true, positive: true }
	},
	async handler(ctx) {
		const id = ctx.params.id;

		const removed = await this.withTx(async (t) => {
			const row = await this.Payment.findByPk(id, { transaction: t, lock: t.LOCK.UPDATE });
			if (!row) throw new Error("Payment not found");
			if (row.status === "paid" || row.status === "refunded") {
				throw new Error("Cannot delete a paid or refunded payment");
			}
			await row.destroy({ transaction: t });
			return { id };
		});

		return removed;
	}
};
