"use strict";

module.exports = {
	rest: {
		method: "POST",
		path: "/:id/mark-paid"
	},
	params: {
		id: { type: "number", integer: true, positive: true }
	},
	async handler(ctx) {
		const id = ctx.params.id;

		const result = await this.withTx(async (t) => {
			const row = await this.Payment.findByPk(id, { transaction: t, lock: t.LOCK.UPDATE });
			if (!row) throw new Error("Payment not found");

			row.status = "paid";
			await row.save({ transaction: t });
			return row;
		});

		return result.toJSON();
	}
};
