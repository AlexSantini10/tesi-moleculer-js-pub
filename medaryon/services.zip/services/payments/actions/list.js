"use strict";

module.exports = {
	rest: {
		method: "GET",
		path: "/"
	},
	params: {
		page: { type: "number", integer: true, positive: true, optional: true, convert: true },
		pageSize: { type: "number", integer: true, positive: true, optional: true, convert: true },
		user_id: { type: "number", integer: true, positive: true, optional: true, convert: true },
		appointment_id: { type: "number", integer: true, positive: true, optional: true, convert: true },
		status: { type: "string", optional: true },
		method: { type: "string", optional: true },
		provider: { type: "string", optional: true },
		sort: { type: "string", optional: true }
	},
	async handler(ctx) {
		const { Op } = this.Payment.sequelize;
		const page = ctx.params.page || 1;
		const pageSize = Math.min(ctx.params.pageSize || 20, 100);

		const where = {};
		if (ctx.params.user_id) where.user_id = ctx.params.user_id;
		if (ctx.params.appointment_id) where.appointment_id = ctx.params.appointment_id;
		if (ctx.params.status) where.status = ctx.params.status;
		if (ctx.params.method) where.method = ctx.params.method;
		if (ctx.params.provider) where.provider = ctx.params.provider;

		let order = [["created_at", "DESC"]];
		if (ctx.params.sort) {
			const parts = String(ctx.params.sort).split(",");
			order = parts.map(s => {
				const [col, dir] = s.trim().split(":");
				return [col || "created_at", (dir || "DESC").toUpperCase()];
			});
		}

		const { rows, count } = await this.Payment.findAndCountAll({
			where,
			order,
			offset: (page - 1) * pageSize,
			limit: pageSize
		});

		return {
			page,
			pageSize,
			total: count,
			items: rows.map(r => r.toJSON())
		};
	}
};
