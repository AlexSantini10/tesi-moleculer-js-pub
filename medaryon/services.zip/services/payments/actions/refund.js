"use strict";

module.exports = {
	rest: {
		method: "POST",
		path: "/:id/refund"
	},
	params: {
		id: { type: "number", integer: true, positive: true },
		reason: { type: "string", optional: true }
	},
	async handler(ctx) {
		const id = ctx.params.id;

		const row = await this.withTx(async (t) => {
			const p = await this.Payment.findByPk(id, { transaction: t, lock: t.LOCK.UPDATE });
			if (!p) throw new Error("Payment not found");
			if (p.status !== "paid") throw new Error("Only paid payments can be refunded");

			p.status = "refunded";
			const meta = Object.assign({}, p.metadata || {}, { refund_reason: ctx.params.reason || null });
			p.metadata = meta;
			await p.save({ transaction: t });
			return p;
		});

		return row.toJSON();
	}
};
