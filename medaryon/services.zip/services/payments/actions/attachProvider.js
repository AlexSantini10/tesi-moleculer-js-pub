"use strict";

module.exports = {
	rest: {
		method: "PATCH",
		path: "/:id/provider"
	},
	params: {
		id: { type: "number", integer: true, positive: true },
		provider: { type: "string" },
		provider_payment_id: { type: "string" },
		metadata: { type: "any", optional: true }
	},
	async handler(ctx) {
		const id = ctx.params.id;

		const updated = await this.withTx(async (t) => {
			const row = await this.Payment.findByPk(id, { transaction: t, lock: t.LOCK.UPDATE });
			if (!row) throw new Error("Payment not found");

			row.provider = ctx.params.provider;
			row.provider_payment_id = ctx.params.provider_payment_id;

			if (ctx.params.metadata != null) {
				const incoming = this.safeParseJSON(ctx.params.metadata) || {};
				const current = row.metadata || {};
				row.metadata = Object.assign({}, current, incoming);
			}

			await row.save({ transaction: t });
			return row;
		});

		return updated.toJSON();
	}
};
