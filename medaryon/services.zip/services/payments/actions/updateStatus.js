"use strict";

module.exports = {
	rest: {
		method: "PATCH",
		path: "/:id/status"
	},
	params: {
		id: { type: "number", integer: true, positive: true },
		status: { type: "string", enum: ["pending", "paid", "failed", "refunded"] }
	},
	async handler(ctx) {
		const id = ctx.params.id;
		const status = ctx.params.status;

		const updated = await this.withTx(async (t) => {
			const row = await this.Payment.findByPk(id, { transaction: t, lock: t.LOCK.UPDATE });
			if (!row) throw new Error("Payment not found");

			if (status === "refunded" && row.status !== "paid") {
				throw new Error("Only paid payments can be refunded");
			}

			row.status = status;
			await row.save({ transaction: t });
			return row;
		});

		return updated.toJSON();
	}
};
