"use strict";

/**
 * Nuovo utente → messaggio di benvenuto.
 * payload.metadata = { userId, role }
 */
module.exports = async function(payload) {
	try {
		const md = payload && payload.metadata ? payload.metadata : {};
		const userId = Number(md.userId || 0);
		if (!userId) return;

		await this.actions.queue({
			user_id: userId,
			channel: "inapp",
			message: "Benvenuto su Medaryon"
		});
	} catch (err) {
		this.logger.warn("user.created notify failed", { err: err && err.message });
	}
};
