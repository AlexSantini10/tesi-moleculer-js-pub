"use strict";

/**
 * Appuntamento riprogrammato → avvisa paziente.
 * payload.metadata = { appointmentId, patientId, doctorId, from: {start,end}, to: {start,end} }
 */
module.exports = async function(payload) {
	try {
		const md = payload && payload.metadata ? payload.metadata : {};
		const patientId = Number(md.patientId || 0);
		if (!patientId || !md.to || !md.to.start) return;

		await this.actions.queue({
			user_id: patientId,
			channel: "inapp",
			message: "Appuntamento riprogrammato per " + new Date(md.to.start).toLocaleString()
		});
	} catch (err) {
		this.logger.warn("appointments.rescheduled notify failed", { err: err && err.message });
	}
};
