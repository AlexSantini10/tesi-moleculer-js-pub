"use strict";

/**
 * Richiesta reset password → avvisa utente (es. via email/push).
 * payload.metadata = { userId }
 */
module.exports = async function(payload) {
	try {
		const md = payload && payload.metadata ? payload.metadata : {};
		const userId = Number(md.userId || 0);
		if (!userId) return;

		await this.actions.queue({
			user_id: userId,
			channel: "inapp",
			message: "Richiesta di reset password ricevuta"
		});
	} catch (err) {
		this.logger.warn("password.reset.requested notify failed", { err: err && err.message });
	}
};
