"use strict";

/**
 * Referto pubblicato → avvisa paziente.
 * payload.metadata = { reportId, appointmentId, patientId }
 */
module.exports = async function(payload) {
	try {
		const md = payload && payload.metadata ? payload.metadata : {};
		const patientId = Number(md.patientId || 0);
		if (!patientId || !md.appointmentId) return;

		await this.actions.queue({
			user_id: patientId,
			channel: "inapp",
			message: "Nuovo referto disponibile per appuntamento #" + md.appointmentId
		});
	} catch (err) {
		this.logger.warn("reports.published notify failed", { err: err && err.message });
	}
};
