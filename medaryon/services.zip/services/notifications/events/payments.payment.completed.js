"use strict";

/**
 * Pagamento riuscito → avvisa l'utente.
 * payload.metadata = { userId?, payerId?, amount, currency, appointmentId? }
 */
module.exports = async function(payload) {
	try {
		const md = payload && payload.metadata ? payload.metadata : {};
		const userId = Number(md.userId || md.payerId || 0);
		if (!userId) return;

		await this.actions.queue({
			user_id: userId,
			channel: "inapp",
			message: "Pagamento confermato: " + md.amount + " " + (md.currency || "EUR")
		});
	} catch (err) {
		this.logger.warn("payments.payment.completed notify failed", { err: err && err.message });
	}
};
