"use strict";

/**
 * Cambio stato appuntamento → avvisa paziente (e volendo il dottore).
 * payload.metadata = { appointmentId, patientId, doctorId, fromStatus, toStatus, scheduledAt }
 */
module.exports = async function(payload) {
	try {
		const md = payload && payload.metadata ? payload.metadata : {};
		const patientId = Number(md.patientId || 0);
		if (!patientId) return;

		const to = String(md.toStatus || "");
		let msg = null;

		if (to === "confirmed") {
			msg = "Appuntamento confermato per " + new Date(md.scheduledAt).toLocaleString();
		} else if (to === "cancelled") {
			msg = "Appuntamento annullato";
		} else if (to === "completed") {
			msg = "Appuntamento completato";
		}

		if (!msg) return;

		await this.actions.queue({
			user_id: patientId,
			channel: "inapp",
			message: msg
		});
	} catch (err) {
		this.logger.warn("appointments.statusChanged notify failed", { err: err && err.message });
	}
};
