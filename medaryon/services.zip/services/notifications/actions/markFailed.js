module.exports = {
	// opzionale: rest: "POST /notifications/:id/fail",
	params: {
		id: { type: "number", convert: true, positive: true },
		reason: { type: "string", optional: true, max: 500 }
	},
	async handler(ctx) {
		const n = await this.Notification.findByPk(ctx.params.id);
		if (!n) this.throwIf(true, "Notification not found", 404, "NOT_FOUND");
		n.status = "failed";
		if (ctx.params.reason) {
			// utile se vuoi loggare il motivo in metadata (se lo aggiungi al model)
			n.reason = ctx.params.reason;
		}
		await n.save();
		return { id: n.id, status: n.status };
	}
};
