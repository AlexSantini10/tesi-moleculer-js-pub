module.exports = {
	// opzionale: rest: "POST /notifications/prune",
	params: {
		olderThanDays: { type: "number", optional: true, convert: true, integer: true, min: 1 }
	},
	async handler(ctx) {
		const days = ctx.params.olderThanDays || 30;
		const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
		const { Op } = require("sequelize");
		const count = await this.Notification.destroy({
			where: {
				status: "sent",
				created_at: { [Op.lt]: cutoff }
			}
		});
		return { pruned: count, olderThanDays: days };
	}
};
