module.exports = {
	visibility: "private",
	params: { id: { type: "number", positive: true, convert: true }, at: { type: "string", optional: true } },
	async handler(ctx) {
		await this.Notification.update(
			{ status: "sent", sent_at: ctx.params.at ? new Date(ctx.params.at) : new Date() },
			{ where: { id: ctx.params.id } }
		);
		const row = await this.Notification.findByPk(ctx.params.id);
		return this.sanitize(row);
	}
};
