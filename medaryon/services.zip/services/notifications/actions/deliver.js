module.exports = {
	visibility: "private",

	params: {
		id: { type: "number", positive: true, convert: true }
	},

	async handler(ctx) {
		const n = await this.Notification.findByPk(ctx.params.id);
		if (!n) return null;
		if (n.status === "sent") return this.sanitize(n);

		const ok = await this._deliverViaChannel(n);
		if (ok) {
			await this.Notification.update(
				{ status: "sent", sent_at: new Date() },
				{ where: { id: n.id } }
			);
		} else {
			await this.Notification.update(
				{ status: "failed", sent_at: null },
				{ where: { id: n.id } }
			);
		}
		const updated = await this.Notification.findByPk(n.id);
		return this.sanitize(updated);
	}
};
