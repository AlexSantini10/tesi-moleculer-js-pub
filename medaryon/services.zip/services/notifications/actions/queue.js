module.exports = {
	visibility: "private",

	params: {
		user_id: { type: "number", positive: true, convert: true },
		message: { type: "string", empty: false },
		channel: { type: "string", empty: false, optional: true }
	},

	async handler(ctx) {
		const channel = (ctx.params.channel || "inapp").toLowerCase();
		const notif = await this.Notification.create({
			user_id: ctx.params.user_id,
			message: ctx.params.message,
			channel,
			status: "pending",
			created_at: new Date()
		});
		return this.sanitize(notif);
	}
};
