"use strict";

const { redact } = require("../utils/redact");

module.exports = {
	async handler(payload, sender, eventName) {
		try {
			const actor = (payload && payload.actor) ? payload.actor : null;
			const data = {
				actor_id: actor && actor.id ? actor.id : 0,
				actor_role: actor && actor.role ? actor.role : "system",
				action: payload && payload.action ? payload.action : eventName || "unknown",
				entity_type: payload && payload.entity_type ? payload.entity_type : null,
				entity_id: payload && payload.entity_id != null ? payload.entity_id : null,
				status: payload && payload.status ? payload.status : "ok",
				metadata: redact(payload && payload.metadata ? payload.metadata : null),
				created_at: new Date()
			};
			await this.Log.create(data);
		} catch (err) {
			this.logger.warn("Failed to record log event", err);
		}
	}
};
