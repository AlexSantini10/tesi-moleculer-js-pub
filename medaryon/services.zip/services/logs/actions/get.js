"use strict";

module.exports = {
	auth: "required",
	params: {
		id: { type: "number", convert: true }
	},
	async handler(ctx) {
		const { id } = ctx.params;
		const log = await this.Log.findByPk(id);
		this.assert(log, "Log not found", 404, "NOT_FOUND");
		this.assert(this.canReadLog(ctx, log), "Forbidden", 403, "FORBIDDEN");
		return log.toJSON();
	}
};
