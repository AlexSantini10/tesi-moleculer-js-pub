"use strict";

const { Op } = require("sequelize");

module.exports = {
	auth: "required",
	params: {
		before: { type: "string" },
		action: { type: "string", optional: true },
		actor_id: { type: "number", optional: true, convert: true }
	},
	async handler(ctx) {
		this.assert(this.isAdmin(ctx), "Forbidden", 403, "FORBIDDEN");

		const where = { created_at: { [Op.lt]: new Date(ctx.params.before) } };
		if (ctx.params.action) where.action = ctx.params.action;
		if (ctx.params.actor_id != null) where.actor_id = ctx.params.actor_id;

		const deleted = await this.Log.destroy({ where });
		return { success: true, deleted };
	}
};
