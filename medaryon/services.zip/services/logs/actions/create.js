"use strict";

const { redact } = require("../utils/redact");

module.exports = {
	auth: "required",
	params: {
		actor_id: { type: "number", convert: true },
		actor_role: { type: "string" },
		action: { type: "string" },
		entity_type: { type: "string", optional: true },
		entity_id: { type: "number", optional: true, convert: true },
		status: { type: "string", optional: true, default: "ok" },
		metadata: { type: "any", optional: true }
	},
	async handler(ctx) {
		const { actor_id, actor_role, action, entity_type, entity_id, status, metadata } = ctx.params;

		this.assert(this.canWriteForActor(ctx, actor_id), "Forbidden", 403, "FORBIDDEN");

		const log = await this.Log.create({
			actor_id,
			actor_role,
			action,
			entity_type: entity_type || null,
			entity_id: entity_id || null,
			status: status || "ok",
			metadata: redact(metadata) || null,
			created_at: new Date()
		});

		return log.toJSON();
	}
};
