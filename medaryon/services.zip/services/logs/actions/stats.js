"use strict";

const { Op, fn, col } = require("sequelize");

module.exports = {
	auth: "required",
	params: {
		from: { type: "string", optional: true },
		to: { type: "string", optional: true },
		groupBy: { type: "string", optional: true, default: "action" }
	},
	async handler(ctx) {
		this.assert(this.isAdmin(ctx), "Forbidden", 403, "FORBIDDEN");

		const where = {};
		if (ctx.params.from) where.created_at = Object.assign(where.created_at || {}, { [Op.gte]: new Date(ctx.params.from) });
		if (ctx.params.to) where.created_at = Object.assign(where.created_at || {}, { [Op.lte]: new Date(ctx.params.to) });

		const groupField = ctx.params.groupBy === "status" ? "status" : "action";

		const rows = await this.Log.findAll({
			where,
			attributes: [[col(groupField), "key"], [fn("COUNT", col("*")), "count"]],
			group: [col(groupField)],
			order: [[col("count"), "DESC"]]
		});

		return rows.map(r => r.toJSON());
	}
};
