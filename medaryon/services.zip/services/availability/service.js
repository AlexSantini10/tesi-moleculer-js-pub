"use strict";

const { Sequelize, DataTypes, Op } = require("sequelize");
const { MoleculerClientError, MoleculerError } = require("moleculer").Errors;
const AvailabilityModel = require("./models/Availability.model.js");

// event handlers che availability ascolta
const onUserDeleted = require("./events/users.user.deleted");
const onUserRoleChanged = require("./events/users.user.role.changed");

module.exports = {
	name: "availability",

	actions: {
		checkSlot: require("./actions/checkSlot"),
		createSlot: require("./actions/createSlot"),
		getAvailability: require("./actions/getAvailability"),
		removeSlot: require("./actions/removeSlot"),
		updateSlot: require("./actions/updateSlot")
	},

	// eventi in ingresso a cui questo servizio reagisce
	events: {
		"users.user.deleted": onUserDeleted,
		"users.user.role.changed": onUserRoleChanged
	},

	methods: {
		getRequester(ctx) {
			return (ctx && ctx.meta && ctx.meta.user) ? ctx.meta.user : null;
		},

		isAdmin(ctx) {
			const requester = this.getRequester(ctx);
			return requester && requester.role === "admin";
		},

		isDoctor(ctx) {
			const requester = this.getRequester(ctx);
			return requester && requester.role === "doctor";
		},

		assert(condition, message, code = 400, type = "BAD_REQUEST", data) {
			if (!condition) throw new MoleculerClientError(message, code, type, data);
		},

		assertAuthorizedDoctor(ctx, doctorId) {
			const user = this.getRequester(ctx);
			this.assert(user, "Unauthorized", 401, "UNAUTHORIZED");
			if (this.isAdmin(ctx)) return;
			this.assert(
				user.role === "doctor" && Number(user.id) === Number(doctorId),
				"Forbidden: can only manage your own availability",
				403,
				"FORBIDDEN"
			);
		},

		validateTimeRange(start, end) {
			this.assert(start && end, "Start and end time are required", 422, "VALIDATION_ERROR");
			if (start >= end) {
				throw new MoleculerClientError(
					"start_time must be before end_time",
					422,
					"INVALID_TIME_RANGE",
					{ start_time: start, end_time: end }
				);
			}
		},

		validateDayOfWeek(day) {
			const n = Number(day);
			this.assert(Number.isInteger(n) && n >= 0 && n <= 6, "day_of_week must be between 0 and 6", 422, "VALIDATION_ERROR");
		},

		async slotConflictExists(doctorId, day, start, end, excludeId = null) {
			const where = {
				doctor_id: doctorId,
				day_of_week: day,
				[Op.or]: [
					{
						start_time: { [Op.lt]: end },
						end_time: { [Op.gt]: start }
					}
				]
			};
			if (excludeId) where.id = { [Op.ne]: excludeId };

			const existing = await this.DoctorAvailability.findOne({ where });
			return !!existing;
		}
	},

	async created() {
		const { DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME } = process.env;
		if (!DB_USER || !DB_PASSWORD || !DB_HOST || !DB_PORT || !DB_NAME) {
			throw new Error("Missing database configuration in environment variables.");
		}

		const dbUri = `mysql://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}`;
		this.logger.info(`Connecting to DB at ${DB_HOST}:${DB_PORT}/${DB_NAME}`);

		this.sequelize = new Sequelize(dbUri, {
			logging: false,
			define: { freezeTableName: true }
		});

		this.DoctorAvailability = AvailabilityModel(this.sequelize, DataTypes);
		await this.DoctorAvailability.sync();

		this.logger.info("Availability model initialized");
	}
};
