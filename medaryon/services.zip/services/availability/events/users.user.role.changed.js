"use strict";

/**
 * Cambio ruolo utente.
 * Se da "doctor" passa ad un ruolo non-doctor, rimuove la disponibilità.
 *
 * payload.data = { userId, from, to }
 */
module.exports = async function(payload) {
	try {
		const data = payload && payload.data ? payload.data : null;
		if (!data) return;

		const userId = Number(data.userId);
		const from = String(data.from || "");
		const to = String(data.to || "");
		if (!userId) return;

		// se non è più doctor, elimina disponibilità
		const wasDoctor = from === "doctor";
		const isDoctor = to === "doctor";
		if (wasDoctor && !isDoctor) {
			const affected = await this.DoctorAvailability.destroy({
				where: { doctor_id: userId }
			});
			this.logger.info("users.user.role.changed -> removed availability", { doctorId: userId, affected });
		}
	} catch (err) {
		this.logger.error("users.user.role.changed handler error", { err: err && err.message });
	}
};
