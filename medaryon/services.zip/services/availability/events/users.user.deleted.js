"use strict";

/**
 * Un utente è stato eliminato/disattivato.
 * Se è un dottore, rimuove tutte le sue disponibilità.
 *
 * payload.data = { userId, reason? }
 */
module.exports = async function(payload) {
	try {
		const data = payload && payload.data ? payload.data : null;
		const userId = data ? Number(data.userId) : null;
		if (!userId) return;

		const affected = await this.DoctorAvailability.destroy({
			where: { doctor_id: userId }
		});

		this.logger.info("users.user.deleted -> removed availability", { doctorId: userId, affected });
	} catch (err) {
		this.logger.error("users.user.deleted handler error", { err: err && err.message });
	}
};
