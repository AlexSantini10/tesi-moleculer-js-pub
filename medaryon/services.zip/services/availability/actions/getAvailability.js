"use strict";

module.exports = {
	auth: "required",
	params: {
		doctor_id: { type: "number", convert: true }
	},
	async handler(ctx) {
		const { doctor_id } = ctx.params;
		const requester = this.getRequester(ctx);
		if (!this.isAdmin(ctx) && !(this.isDoctor(ctx) && requester.id === doctor_id)) {
			this.assert(false, "Forbidden", 403, "FORBIDDEN");
		}

		const slots = await this.DoctorAvailability.findAll({
			where: { doctor_id },
			order: [["day_of_week", "ASC"], ["start_time", "ASC"]]
		});
		return slots.map(s => s.toJSON());
	}
};
