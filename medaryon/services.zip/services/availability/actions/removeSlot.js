"use strict";

module.exports = {
	auth: "required",
	params: {
		id: { type: "number", convert: true }
	},
	async handler(ctx) {
		const { id } = ctx.params;
		const slot = await this.DoctorAvailability.findByPk(id);
		this.assert(slot, "Slot not found", 404, "NOT_FOUND");

		this.assertAuthorizedDoctor(ctx, slot.doctor_id);
		await slot.destroy();

		return { success: true };
	}
};
