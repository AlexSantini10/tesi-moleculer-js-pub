"use strict";

module.exports = {
	auth: "required",
	params: {
		id: { type: "number", convert: true },
		day_of_week: { type: "number", integer: true, min: 0, max: 6, optional: true, convert: true },
		start_time: { type: "string", optional: true },
		end_time: { type: "string", optional: true }
	},
	async handler(ctx) {
		const { id, day_of_week, start_time, end_time } = ctx.params;
		const slot = await this.DoctorAvailability.findByPk(id);
		this.assert(slot, "Slot not found", 404, "NOT_FOUND");

		this.assertAuthorizedDoctor(ctx, slot.doctor_id);

		if (day_of_week !== undefined) this.validateDayOfWeek(day_of_week);
		if (start_time || end_time) {
			this.validateTimeRange(start_time || slot.start_time, end_time || slot.end_time);
		}

		if (await this.slotConflictExists(
			slot.doctor_id,
			day_of_week !== undefined ? day_of_week : slot.day_of_week,
			start_time !== undefined ? start_time : slot.start_time,
			end_time !== undefined ? end_time : slot.end_time,
			id
		)) {
			this.assert(false, "Slot conflicts with existing availability", 409, "CONFLICT");
		}

		Object.assign(slot, {
			day_of_week: day_of_week !== undefined ? day_of_week : slot.day_of_week,
			start_time: start_time !== undefined ? start_time : slot.start_time,
			end_time: end_time !== undefined ? end_time : slot.end_time
		});
		await slot.save();

		return slot.toJSON();
	}
};
