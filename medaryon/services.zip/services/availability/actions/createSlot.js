"use strict";

module.exports = {
	auth: "required",
	params: {
		doctor_id: { type: "number", convert: true },
		day_of_week: { type: "number", integer: true, min: 0, max: 6, convert: true },
		start_time: { type: "string" },
		end_time: { type: "string" }
	},
	async handler(ctx) {
		const { doctor_id, day_of_week, start_time, end_time } = ctx.params;
		this.assertAuthorizedDoctor(ctx, doctor_id);
		this.validateDayOfWeek(day_of_week);
		this.validateTimeRange(start_time, end_time);

		if (await this.slotConflictExists(doctor_id, day_of_week, start_time, end_time)) {
			this.assert(false, "Slot conflicts with existing availability", 409, "CONFLICT");
		}

		const slot = await this.DoctorAvailability.create({
			doctor_id,
			day_of_week,
			start_time,
			end_time
		});
		return slot.toJSON();
	}
};
