const Errors = require("../../../errors");

module.exports = {
	rest: "DELETE /reports/:id",
	auth: "required",

	params: {
		id: { type: "number", convert: true }
	},

	async handler(ctx) {
		const user = ctx.meta.user;
		if (!user || !user.id) throw Errors.UnauthorizedAccessError();

		const report = await this.Report.findByPk(ctx.params.id);
		if (!report) return { deleted: 0 };

		if (user.role !== "admin") {
			if (report.author_id !== user.id || report.author_role !== user.role) {
				throw Errors.ForbiddenError();
			}
		}

		const deleted = await this.Report.destroy({ where: { id: report.id } });
		return { deleted };
	}
};
