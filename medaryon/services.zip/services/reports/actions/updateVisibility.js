const Errors = require("../../../errors");

module.exports = {
	rest: "PATCH /reports/:id/visibility",
	auth: "required",

	params: {
		id: { type: "number", convert: true },
		visibleToPatient: { type: "boolean", optional: true },
		visibleToDoctor: { type: "boolean", optional: true }
	},

	async handler(ctx) {
		const user = ctx.meta.user;
		if (!user || !user.id) throw Errors.UnauthorizedAccessError();

		const report = await this.Report.findByPk(ctx.params.id);
		if (!report) throw Errors.NotFoundError("Report not found");

		const appt = await this.getAppointment(ctx, report.appointment_id);

		if (user.role !== "admin") {
			if (report.author_id !== user.id || report.author_role !== user.role) {
				throw Errors.ForbiddenError();
			}
		}

		const updates = {};
		if (ctx.params.visibleToPatient !== undefined) updates.visible_to_patient = !!ctx.params.visibleToPatient;
		if (ctx.params.visibleToDoctor !== undefined) updates.visible_to_doctor = !!ctx.params.visibleToDoctor;
		if (Object.keys(updates).length === 0) return report;

		updates.updated_at = new Date();
		await this.Report.update(updates, { where: { id: report.id } });
		return this.Report.findByPk(report.id);
	}
};
