const Errors = require("../../../errors");

module.exports = {
	rest: "POST /reports/doctor",
	auth: "required",

	params: {
		appointmentId: { type: "number", positive: true, convert: true },
		reportUrl: { type: "string", empty: false },
		title: { type: "string", optional: true, max: 255 },
		notes: { type: "string", optional: true },
		mimeType: { type: "string", optional: true, max: 100 },
		sizeBytes: { type: "number", integer: true, optional: true, convert: true },
		visibleToPatient: { type: "boolean", optional: true }
	},

	async handler(ctx) {
		const user = ctx.meta.user;
		if (!user || !user.id) throw Errors.UnauthorizedAccessError();
		if (user.role !== "doctor" && user.role !== "admin") throw Errors.ForbiddenError();

		const appt = await this.getAppointment(ctx, ctx.params.appointmentId);
		if (!appt) throw Errors.NotFoundError("Appointment not found");
		if (user.role !== "admin" && appt.doctor_id !== user.id) throw Errors.ForbiddenError();

		const data = {
			appointment_id: appt.id,
			author_id: user.id,
			author_role: "doctor",
			title: ctx.params.title || null,
			notes: ctx.params.notes || null,
			report_url: ctx.params.reportUrl,
			mime_type: ctx.params.mimeType || null,
			size_bytes: ctx.params.sizeBytes || null,
			visible_to_patient: ctx.params.visibleToPatient !== undefined ? !!ctx.params.visibleToPatient : true,
			visible_to_doctor: true
		};

		return this.Report.create(data);
	}
};
