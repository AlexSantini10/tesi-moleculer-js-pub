const { Op } = require("sequelize");
const Errors = require("../../../errors");
const { filterWhereForRole } = require("../utils/visibility");

module.exports = {
	rest: "GET /appointments/:appointmentId/reports",
	auth: "required",

	params: {
		appointmentId: { type: "number", convert: true }
	},

	async handler(ctx) {
		const user = ctx.meta.user;
		if (!user || !user.id) throw Errors.UnauthorizedAccessError();

		const appt = await this.getAppointment(ctx, ctx.params.appointmentId);
		if (!appt) throw Errors.NotFoundError("Appointment not found");

		if (!this.canAccessAppointment(user, appt)) throw Errors.ForbiddenError();

		const roleFilter = filterWhereForRole(user.role, user.id);
		const where = {
			appointment_id: appt.id,
			[Op.or]: Array.isArray(roleFilter) ? roleFilter : [roleFilter]
		};

		return this.Report.findAll({ where, order: [["created_at", "ASC"]] });
	}
};
