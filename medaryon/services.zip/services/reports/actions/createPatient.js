const Errors = require("../../../errors");

module.exports = {
	rest: "POST /patient",

	params: {
		appointmentId: { type: "number", positive: true, convert: true },
		reportUrl: { type: "string", empty: false },
		title: { type: "string", optional: true, max: 255 },
		notes: { type: "string", optional: true },
		mimeType: { type: "string", optional: true, max: 100 },
		sizeBytes: { type: "number", integer: true, optional: true, convert: true },
		visibleToDoctor: { type: "boolean", optional: true }
	},

	async handler(ctx) {
		const user = ctx.meta && ctx.meta.user ? ctx.meta.user : null;
		if (!user || !user.id) throw Errors.UnauthorizedAccessError();
		if (user.role !== "patient" && user.role !== "admin") throw Errors.ForbiddenError();

		const appt = await this.getAppointment(ctx, ctx.params.appointmentId);
		if (!appt) throw Errors.NotFoundError("Appointment not found");
		if (user.role !== "admin" && Number(appt.patient_id) !== Number(user.id)) throw Errors.ForbiddenError();

		const data = {
			appointment_id: appt.id,
			author_id: user.id,
			author_role: "patient",
			title: ctx.params.title || null,
			notes: ctx.params.notes || null,
			report_url: ctx.params.reportUrl,
			mime_type: ctx.params.mimeType || null,
			size_bytes: ctx.params.sizeBytes || null,
			visible_to_patient: true,
			visible_to_doctor: ctx.params.visibleToDoctor !== undefined ? !!ctx.params.visibleToDoctor : true
		};

		const row = await this.Report.create(data);
		return row.toJSON();
	}
};
