const Errors = require("../../../errors");

module.exports = {
	rest: "GET /reports/:id",
	auth: "required",

	params: {
		id: { type: "number", convert: true }
	},

	async handler(ctx) {
		const user = ctx.meta.user;
		if (!user || !user.id) throw Errors.UnauthorizedAccessError();

		const report = await this.Report.findByPk(ctx.params.id);
		if (!report) throw Errors.NotFoundError("Report not found");

		const appt = await this.getAppointment(ctx, report.appointment_id);
		if (!this.canSeeReport(user, report, appt)) throw Errors.ForbiddenError();

		return report;
	}
};
