const { isAdmin } = require("../utils/permissions");
const Errors = require("../../../errors");

module.exports = {
	auth: "required",

	params: {
		id: "number"
	},

	async handler(ctx) {
		const { user } = ctx.meta;
		const targetId = ctx.params.id;

		if (!isAdmin(user)) {
			this.logger.warn("Unauthorized attempt to delete user", {
				adminAttemptedBy: user.id,
				targetId
			});
			throw Errors.ForbiddenAccessError("Only admins can delete users");
		}

		try {
			const record = await this.User.findByPk(targetId);

			if (!record) {
				this.logger.warn("Attempted to delete non-existent user", { targetId });
				throw Errors.UserNotFoundError(targetId);
			}

			await record.destroy();

			this.logger.info("User deleted", { deletedId: targetId, by: user.id });

			return { message: "User deleted" };
		} catch (err) {
			this.logger.error("Error deleting user", err);
			throw Errors.DBError(err.message);
		}
	}
};
