const { isOwnerOrAdmin } = require("../utils/permissions");
const Errors = require("../../../errors");

module.exports = {
	auth: "required",

	params: {
		id: "number",
		first_name: { type: "string", optional: true },
		last_name: { type: "string", optional: true }
	},

	async handler(ctx) {
		const { id, first_name, last_name } = ctx.params;
		const { user } = ctx.meta;

		if (!isOwnerOrAdmin(user, id)) {
			this.logger.warn("Unauthorized update attempt", { by: user.id, targetId: id });
			throw Errors.UnauthorizedAccessError();
		}

		try {
			const record = await this.User.findByPk(id);

			if (!record) {
				this.logger.warn("Update failed: user not found", { targetId: id });
				throw Errors.UserNotFoundError(id);
			}

			await record.update({ first_name, last_name });

			this.logger.info("User updated", {
				by: user.id,
				targetId: record.id,
				updated: { first_name, last_name }
			});

			return record;
		} catch (err) {
			this.logger.error("Error updating user", err);
			throw Errors.DBError(err.message);
		}
	}
};
