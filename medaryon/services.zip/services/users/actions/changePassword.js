const bcrypt = require("bcrypt");
const Errors = require("../../../errors");

module.exports = {
	auth: "required",

	params: {
		userId: "number",
		oldPassword: "string|min:6",
		newPassword: "string|min:6"
	},

	async handler(ctx) {
		const { userId, oldPassword, newPassword } = ctx.params;
		const currentUser = ctx.meta.user;

		// (opzionale) impedisci che un utente cambi password di altri
		if (currentUser.id !== userId && currentUser.role !== "admin") {
			throw Errors.ForbiddenAccessError("You can only change your own password");
		}

		const user = await this.User.findByPk(userId);
		if (!user) {
			this.logger.warn("User not found", { userId });
			throw Errors.UserNotFoundError(userId);
		}

		const valid = await bcrypt.compare(oldPassword, user.password);
		if (!valid) {
			this.logger.warn("Incorrect old password", { userId });
			throw Errors.UnauthorizedAccessError();
		}

		try {
			const hashed = await bcrypt.hash(newPassword, 10);
			await user.update({ password: hashed });

			this.logger.info("Password changed", { userId });
			return { message: "Password updated successfully" };
		} catch (err) {
			this.logger.error("Error updating password", err);
			throw Errors.DBError(err.message);
		}
	}
};
