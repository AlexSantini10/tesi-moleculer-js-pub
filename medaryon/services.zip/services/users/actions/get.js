const { isOwnerOrAdmin } = require("../utils/permissions");
const Errors = require("../../../errors");

module.exports = {
	auth: "required",

	params: {
		id: "string" // accetta anche da URL
	},

	async handler(ctx) {
		const targetId = parseInt(ctx.params.id, 10);
		const user = ctx.meta && ctx.meta.user;

		// Validazione ID
		if (isNaN(targetId)) {
			this.logger.warn("Invalid user ID in get", { rawId: ctx.params.id });
			throw Errors.ValidationError("Invalid user ID");
		}

		// Validazione presenza user
		if (!user || !user.id) {
			this.logger.warn("Missing or invalid user in context", { meta: ctx.meta });
			throw Errors.UnauthorizedAccessError();
		}

		// Controllo permessi
		if (!isOwnerOrAdmin(user, targetId)) {
			this.logger.warn("Unauthorized get attempt", { by: user.id, targetId });
			throw Errors.UnauthorizedAccessError();
		}

		try {
			const result = await this.User.findByPk(targetId);

			if (!result) {
				this.logger.warn("User not found", { targetId });
				throw Errors.UserNotFoundError(targetId);
			}

			return result;
		} catch (err) {
			this.logger.error("Error in get user", err);
			throw Errors.DBError(err.message);
		}
	}
};
