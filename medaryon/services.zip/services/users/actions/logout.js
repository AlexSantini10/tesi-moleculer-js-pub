const Errors = require("../../../errors");

module.exports = {
	auth: "required", // Richiede JWT

	async handler(ctx) {
		const user = ctx.meta.user;

		if (!user) {
			this.logger.warn("Logout attempted without valid user in context");
			throw Errors.UnauthorizedAccessError();
		}

		this.logger.info("User logged out", { userId: user.id, email: user.email });

		// FUTURO: invalidare token o salvarlo in una blacklist
		return { message: "Logged out successfully" };
	}
};
