const { isAdmin } = require("../utils/permissions");
const Errors = require("../../../errors");

module.exports = {
	auth: "required",

	async handler(ctx) {
		const { user } = ctx.meta;

		if (!isAdmin(user)) {
			this.logger.warn("Unauthorized access to list users", { userId: user.id });
			throw Errors.ForbiddenAccessError("Only admins can list all users");
		}

		try {
			const users = await this.User.findAll();
			this.logger.info("Users listed by admin", { adminId: user.id, count: users.length });
			return users;
		} catch (err) {
			this.logger.error("Error listing users", err);
			throw Errors.DBError(err.message);
		}
	}
};
