const bcrypt = require("bcrypt");
const { Errors } = require("moleculer");

const { MoleculerClientError, MoleculerError } = Errors;
const VALID_ROLES = ["patient", "doctor", "admin"];

module.exports = {
    params: {
        email: "email",
        password: "string|min:6",
        role: { type: "string", optional: true, default: "patient" },
        first_name: { type: "string", optional: true },
        last_name: { type: "string", optional: true }
    },

    async handler(ctx) {
        const { email, password, role, first_name, last_name } = ctx.params;

        this.logger.info("Creating user", { email, role });

        // ruolo valido
        if (!VALID_ROLES.includes(role)) {
            throw new MoleculerClientError("Invalid role", 422, "INVALID_ROLE", { role });
        }

        // solo admin può creare admin
        if (role === "admin") {
            const requester = ctx.meta && ctx.meta.user ? ctx.meta.user : null;
            if (!requester || requester.role !== "admin") {
                throw new MoleculerClientError("Only admins can create admin users", 403, "FORBIDDEN");
            }
        }

        // normalizza email
        const normalizedEmail = String(email).trim().toLowerCase();

        try {
            // pre-check unicità (non sostituisce il vincolo a DB)
            const existing = await this.User.findOne({ where: { email: normalizedEmail } });
            if (existing) {
                throw new MoleculerClientError("Email already in use", 409, "EMAIL_EXISTS", { field: "email" });
            }

            // hash password
            let hashedPassword;
            try {
                hashedPassword = await bcrypt.hash(password, 10);
            } catch (hashErr) {
                this.logger.error("Password hash failed", hashErr);
                throw new MoleculerError("Password hashing failed", 500, "HASH_ERROR");
            }

            // create utente
            const user = await this.User.create({
                email: normalizedEmail,
                password: hashedPassword,
                role,
                first_name,
                last_name
            });

            this.logger.info("User created", { id: user.id, email: user.email });

            return {
                id: user.id,
                email: user.email,
                role: user.role
            };
        } catch (err) {
            // mapping errori sequelize -> http
            if (err && (err.name === "SequelizeUniqueConstraintError" || err?.parent?.code === "ER_DUP_ENTRY")) {
                throw new MoleculerClientError("Email already in use", 409, "EMAIL_EXISTS", { field: "email" });
            }

            if (err && err.name === "SequelizeValidationError") {
                throw new MoleculerClientError("Validation error", 422, "VALIDATION_ERROR", {
                    errors: (err.errors || []).map(e => ({
                        message: e.message,
                        path: e.path,
                        value: e.value
                    }))
                });
            }

            if (err && err.name === "SequelizeForeignKeyConstraintError") {
                throw new MoleculerClientError("Invalid reference", 400, "FK_CONSTRAINT", {
                    message: err.message
                });
            }

            if (err && (err.name === "SequelizeConnectionError"
                || err.name === "SequelizeConnectionRefusedError"
                || err.name === "SequelizeHostNotFoundError"
                || err.name === "SequelizeHostNotReachableError"
                || err.name === "SequelizeInvalidConnectionError"
                || err.name === "SequelizeConnectionTimedOutError")) {
                this.logger.error("DB connection error", err);
                throw new MoleculerError("Database unavailable", 503, "DB_UNAVAILABLE");
            }

            if (err instanceof MoleculerClientError || err instanceof MoleculerError) {
                throw err;
            }

            this.logger.error("Failed to create user", err);
            throw new MoleculerError("Failed to create user", 500, "DB_ERROR", { message: err && err.message });
        }
    }
};
