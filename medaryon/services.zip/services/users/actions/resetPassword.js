const bcrypt = require("bcrypt");
const Errors = require("../../../errors");

module.exports = {
	params: {
		token: "string",
		newPassword: "string|min:6"
	},

	async handler(ctx) {
		const { token, newPassword } = ctx.params;

		const userId = this.passwordResetTokens && this.passwordResetTokens[token];
		if (!userId) {
			this.logger.warn("Password reset with invalid or expired token", { token });
			throw Errors.UnauthorizedAccessError();
		}

		try {
			const user = await this.User.findByPk(userId);
			if (!user) {
				this.logger.warn("Password reset failed: user not found", { userId });
				throw Errors.UserNotFoundError(userId);
			}

			const hashed = await bcrypt.hash(newPassword, 10);
			await user.update({ password: hashed });

			delete this.passwordResetTokens[token];

			this.logger.info("Password reset successful", { userId });

			return { message: "Password reset successful" };
		} catch (err) {
			this.logger.error("Error during password reset", err);
			throw Errors.DBError(err.message);
		}
	}
};
