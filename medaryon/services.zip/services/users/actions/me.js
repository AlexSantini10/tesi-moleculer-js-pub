const Errors = require("../../../errors");

module.exports = {
	auth: "required",

	params: {},

	async handler(ctx) {
		this.logger.info("🔍 [users.me] Handler called");
		this.logger.debug("🔍 [users.me] Incoming meta:", ctx.meta);

		const user = ctx.meta && ctx.meta.user;

		if (!user) {
			this.logger.warn("⚠️ [users.me] No user in ctx.meta");
		} else {
			this.logger.info("👤 [users.me] Received user in meta:", user);
		}

		if (!user || !user.id) {
			this.logger.warn("❌ [users.me] Missing or invalid user in context", { meta: ctx.meta });
			throw Errors.UnauthorizedAccessError();
		}

		this.logger.info("📦 [users.me] Searching for user in DB with ID:", user.id);

		try {
			const foundUser = await this.User.findByPk(user.id);

			if (!foundUser) {
				this.logger.warn("❌ [users.me] Authenticated user not found in DB", { userId: user.id });
				throw Errors.UserNotFoundError(user.id);
			}

			this.logger.info("✅ [users.me] Authenticated user retrieved:", {
				id: foundUser.id,
				email: foundUser.email
			});

			return foundUser;
		} catch (err) {
			this.logger.error("💥 [users.me] Error retrieving authenticated user", {
				message: err.message,
				stack: err.stack
			});
			throw Errors.DBError(err.message);
		}
	}
};
