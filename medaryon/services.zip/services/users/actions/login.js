const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { MoleculerError } = require("moleculer").Errors;
const Errors = require("../../../errors");

module.exports = {
	params: {
		email: "email",
		password: "string|min:6"
	},

	async handler(ctx) {
		const { email, password } = ctx.params;

		try {
			const user = await this.User.findOne({ where: { email } });
			if (!user || !user.password) {
				this.logger.warn("Login failed: unknown email", { email });
				throw Errors.LoginFailedError();
			}

			const match = await bcrypt.compare(password, user.password);
			if (!match) {
				this.logger.warn("Login failed: wrong password", { email });
				throw Errors.LoginFailedError();
			}

			const token = jwt.sign(
				{ id: user.id, email: user.email, role: user.role },
				process.env.JWT_SECRET,
				{ expiresIn: "1d" }
			);

			this.logger.info("User logged in", { userId: user.id, email });

			return {
				token,
			     	user: {
					id: user.id,
					email: user.email,
					role: user.role,
					first_name: user.first_name,
					last_name: user.last_name
				}
			};
		} catch (err) {
			this.logger.error("Login error", err);
			// non rimappare l’errore di credenziali
			if (
				err?.type === "LOGIN_FAILED" ||
				err?.code === "LOGIN_FAILED" ||
				(err instanceof MoleculerError && err.type === "LOGIN_FAILED")
			) {
				throw err;
			}
			throw Errors.DBError(err.message || "Database error");
		}
	}
};
