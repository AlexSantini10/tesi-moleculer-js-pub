const crypto = require("crypto");
const Errors = require("../../../errors");

module.exports = {
	params: {
		email: "email"
	},

	async handler(ctx) {
		const { email } = ctx.params;

		try {
			const user = await this.User.findOne({ where: { email } });
			if (!user) {
				this.logger.warn("Reset password requested for non-existent email", { email });
				throw Errors.UserNotFoundError(email);
			}

			const token = crypto.randomBytes(32).toString("hex");

			// In un'app reale, salva il token con scadenza (es: Redis, DB)
			this.passwordResetTokens = this.passwordResetTokens || {};
			this.passwordResetTokens[token] = user.id;

			// Simula invio email
			this.logger.info(`Send reset link to ${email} with token: ${token}`);

			return { message: "Reset link sent" };
		} catch (err) {
			this.logger.error("Error in forgotPassword", err);
			throw Errors.DBError(err.message);
		}
	}
};
