const { Sequelize, DataTypes } = require("sequelize");
const UserModel = require("./models/User.model.js");

module.exports = {
	name: "users",

	actions: {
		list: require("./actions/list"),
		get: require("./actions/get"),
		register: require("./actions/register"),
		update: require("./actions/update"),
		delete: require("./actions/delete"),
		changePassword: require("./actions/changePassword"),
		me: require("./actions/me"),
		forgotPassword: require("./actions/forgotPassword"),
		resetPassword: require("./actions/resetPassword"),
		login: require("./actions/login"),
		logout: require("./actions/logout")
	},

	async created() {
		// Verifica che le variabili siano presenti
		const { DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME } = process.env;
		if (!DB_USER || !DB_PASSWORD || !DB_HOST || !DB_PORT || !DB_NAME) {
			throw new Error("Missing database configuration in environment variables.");
		}

		// Costruisce dinamicamente la URI
		const dbUri = `mysql://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}`;
		this.logger.info(`Connecting to DB at ${DB_HOST}:${DB_PORT}/${DB_NAME}`);

		// Crea connessione Sequelize
		this.sequelize = new Sequelize(dbUri, {
			logging: false,
			define: {
				freezeTableName: true
			}
		});

		// Inizializza il modello User
		this.User = UserModel(this.sequelize, DataTypes);
		await this.User.sync(); // in dev: .sync({ alter: true })

		this.logger.info("User model initialized");
		
		// Store temporaneo per reset password
		this.passwordResetTokens = {};
	}
};
